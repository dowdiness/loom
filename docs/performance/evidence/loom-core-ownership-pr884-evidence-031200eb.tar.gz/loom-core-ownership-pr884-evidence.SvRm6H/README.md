# PR #884 Core Ownership Benchmark Evidence

Baseline commit: `031200eb552db96351f6ff84dfc9c414ec8b5dde`.

This bundle preserves accepted and rejected controls so the recorded baseline
is auditable without selecting only passing attempts.

- `accepted-baseline/`: original clean same-commit baseline control. Both sides
  and the runner use the baseline commit.
- `accepted-current/`: final verification of the baseline against runner commit
  `95db812e0b31194991adadff3ce00778153d04d3`. It includes runner blob IDs,
  relative-MAD reports, paired samples, paired medians, and the final comparison.
- `rejected-predecessor/`: an earlier runner control rejected by the 5% gate.
- `rejected-unstable/`: a same-baseline control with large dispersion. The final
  5% relative-MAD policy rejects all ten required candidate rows.
- `rejected-independent-median/`: a stable run where comparing independent
  medians reported a false 5.61% Lambda regression. Its within-pair percentages
  have a 3.62% median, motivating the final paired estimator.

Every run directory contains its original raw Moon output, parsed samples,
environment records, policy, metadata, and available derived reports.
